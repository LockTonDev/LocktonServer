const authController = require('../controllers/authController');
const C_ADMIN = require('../controllers/C_ADMIN');
const C_ADMIN_MASTER = require('../controllers/C_ADMIN_MASTER');
const passport = require('passport');
const express = require('express');
const router = new express.Router();

const LocalPassportAuth = passport.authenticate('local', { session: false }); //id, pw 검증
const { verifyToken } = require('../middleware/auth');

router.post('/SYSTEM/get', verifyToken, C_ADMIN.getSystemInfo);
router.post('/COM/setUsersTemp', verifyToken, C_ADMIN.setUsersTemp);
router.post('/COM/getStockStartDtInfo', verifyToken, C_ADMIN.getStockStartDtInfo);

router.post('/USER_REG_NO/set', verifyToken, C_ADMIN.setUserRegNo);
router.post('/USER_REG_NO/gets', verifyToken, C_ADMIN.getUserRegNo);

router.post('/BOARD/get', verifyToken, C_ADMIN.getBoardInfo);
router.post('/BOARD/gets', verifyToken, C_ADMIN.getBoardList);
router.post('/BOARD/ins', verifyToken, C_ADMIN.setInsertBoard);
router.post('/BOARD/udt', verifyToken, C_ADMIN.setUpdateBoard);
router.post('/BOARD/del', verifyToken, C_ADMIN.setDeleteBoard);

router.post('/USER/setUserLoginBlockReset', verifyToken, C_ADMIN.setUserLoginBlockReset);
router.post('/USER/get', verifyToken, C_ADMIN.getUserInfo);
router.post('/USER/gets', verifyToken, C_ADMIN.getUserList);
router.post('/USER/set', verifyToken, C_ADMIN.setUserInfo);
router.post('/USER/setUserPassword', verifyToken, C_ADMIN.setUserPassword);
router.post('/USER/EXCEL/get', verifyToken, C_ADMIN.getUserExcel);

router.post('/TAX/EXCEL/get', verifyToken, C_ADMIN.getTAXExcel);
router.post('/TAX/EXCEL/renewal/gets', verifyToken, C_ADMIN.getTAXRenewalExcel);

router.post('/TAX/APPLY/set', verifyToken, C_ADMIN.setApplyInsurance);
router.post('/TAX/APPLY/get', verifyToken, C_ADMIN.getApplyInsurance);

router.post('/TAX/TRX/set', verifyToken, C_ADMIN.setTAX_TRX);
router.post('/TAX/TRX/get', verifyToken, C_ADMIN.getTAX_TRX);

router.post('/TAX/rate', verifyToken, C_ADMIN.getTAXRate);
router.post('/TAX/get', verifyToken, C_ADMIN.getTAX);
router.post('/TAX/gets', verifyToken, C_ADMIN.getTAXS);
router.post('/TAX/renewal/get', verifyToken, C_ADMIN.getRenewal);
router.post('/TAX/renewal/gets', verifyToken, C_ADMIN.getRenewals);
router.post('/TAX/set', verifyToken, C_ADMIN.setTAX);
router.post('/TAX/renewal/set', verifyToken, C_ADMIN.setTAXRenewal);

router.post('/ADV/rate', verifyToken, C_ADMIN.getADVRate);
router.post('/ADV/set', verifyToken, C_ADMIN.setADV);
router.post('/ADV/get', verifyToken, C_ADMIN.getADV);
router.post('/ADV/gets', verifyToken, C_ADMIN.getADVS);
router.post('/ADV/renewal/set', verifyToken, C_ADMIN.setADVRenewal);
router.post('/ADV/renewal/get', verifyToken, C_ADMIN.getADVRenewal);
router.post('/ADV/renewal/gets', verifyToken, C_ADMIN.getADVRenewals);
router.post('/ADV/TRX/set', verifyToken, C_ADMIN.setADV_TRX);
router.post('/ADV/TRX/get', verifyToken, C_ADMIN.getADV_TRX);
router.post('/ADV/APPLY/set', verifyToken, C_ADMIN.setApplyADVInsurance);
router.post('/ADV/APPLY/get', verifyToken, C_ADMIN.getApplyADVInsurance);
router.post('/ADV/EXCEL/get', verifyToken, C_ADMIN.getADVExcel);

router.post('/CAA/rate', verifyToken, C_ADMIN.getCAARate);
router.post('/CAA/set', verifyToken, C_ADMIN.setCAA);
router.post('/CAA/get', verifyToken, C_ADMIN.getCAA);
router.post('/CAA/gets', verifyToken, C_ADMIN.getCAAS);
router.post('/CAA/renewal/set', verifyToken, C_ADMIN.setCAARenewal);
router.post('/CAA/renewal/get', verifyToken, C_ADMIN.getCAARenewal);
router.post('/CAA/renewal/gets', verifyToken, C_ADMIN.getCAARenewals);
router.post('/CAA/TRX/set', verifyToken, C_ADMIN.setCAA_TRX);
router.post('/CAA/TRX/get', verifyToken, C_ADMIN.getCAA_TRX);
router.post('/CAA/APPLY/set', verifyToken, C_ADMIN.setApplyCAAInsurance);
router.post('/CAA/APPLY/get', verifyToken, C_ADMIN.getApplyCAAInsurance);
router.post('/CAA/EXCEL/get', verifyToken, C_ADMIN.getCAAExcel);
router.delete('/CAA/del', verifyToken, C_ADMIN.deleteCAA);

router.post('/PAT/rate', verifyToken, C_ADMIN.getPATRate);
router.post('/PAT/set', verifyToken, C_ADMIN.setPAT);
router.post('/PAT/get', verifyToken, C_ADMIN.getPAT);
router.post('/PAT/gets', verifyToken, C_ADMIN.getPATS);
router.post('/PAT/renewal/set', verifyToken, C_ADMIN.setPATRenewal);
router.post('/PAT/renewal/get', verifyToken, C_ADMIN.getPATRenewal);
router.post('/PAT/renewal/gets', verifyToken, C_ADMIN.getPATRenewals);
router.post('/PAT/TRX/set', verifyToken, C_ADMIN.setPAT_TRX);
router.post('/PAT/TRX/get', verifyToken, C_ADMIN.getPAT_TRX);
router.post('/PAT/APPLY/set', verifyToken, C_ADMIN.setApplyPATInsurance);
router.post('/PAT/APPLY/get', verifyToken, C_ADMIN.getApplyPATInsurance);
router.post('/PAT/EXCEL/get', verifyToken, C_ADMIN.getPATExcel);
router.post('/PAT/downloadIncomeFile', verifyToken, C_ADMIN.downloadIncomeFile);

router.post('/LAW/rate', verifyToken, C_ADMIN.getLAWRate);
router.post('/LAW/set', verifyToken, C_ADMIN.setLAW);
router.post('/LAW/get', verifyToken, C_ADMIN.getLAW);
router.post('/LAW/gets', verifyToken, C_ADMIN.getLAWS);
router.post('/LAW/renewal/set', verifyToken, C_ADMIN.setLAWRenewal);
router.post('/LAW/renewal/get', verifyToken, C_ADMIN.getLAWRenewal);
router.post('/LAW/renewal/gets', verifyToken, C_ADMIN.getLAWRenewals);
router.post('/LAW/EXCEL/renewal/gets', verifyToken, C_ADMIN.getLAWRenewalsExcel); //getTAXRenewalExcel
router.post('/LAW/TRX/set', verifyToken, C_ADMIN.setLAW_TRX);
router.post('/LAW/TRX/get', verifyToken, C_ADMIN.getLAW_TRX);
router.post('/LAW/APPLY/set', verifyToken, C_ADMIN.setApplyLAWInsurance);
router.post('/LAW/APPLY/get', verifyToken, C_ADMIN.getApplyLAWInsurance);
router.post('/LAW/EXCEL/get', verifyToken, C_ADMIN.getLAWExcel);

router.post('/MASTER/getRenwalInsurance', verifyToken, C_ADMIN.getRenwalInsurance);
router.post('/MASTER/insurance', verifyToken, C_ADMIN_MASTER.getInsuranceMaster);
router.post('/MASTER/insurance/set', verifyToken, C_ADMIN_MASTER.setInsuranceMaster);
router.post('/MASTER/insurance/chkDup', verifyToken, C_ADMIN_MASTER.chkDupInsuranceMaster);
router.post('/MASTER/insurance/chgInsuranceNo', verifyToken, C_ADMIN_MASTER.chgInsuranceNo);



module.exports = router;
